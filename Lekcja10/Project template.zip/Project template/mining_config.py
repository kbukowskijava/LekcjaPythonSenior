# Your Address
MINER_ADDRESS = "q3nf394hjg-random-miner-address-34nf3i4nflkn3oi"

# Localhost
MINER_NODE_URL = "http://localhost:5000"

PEER_NODES = []